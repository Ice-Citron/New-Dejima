export function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export function formatCost(n: number): string {
  return `$${n.toFixed(2)}`;
}

export function formatDate(dateStr: string): string {
  const parts = dateStr.split("-");
  return `${parts[1]}-${parts[2]}`;
}
