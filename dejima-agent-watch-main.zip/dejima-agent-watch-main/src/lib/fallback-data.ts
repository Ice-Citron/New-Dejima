export interface AgentProduction {
  name: string;
  type: string;
  status: "verified" | "compiled" | "demo";
  size: string;
  date: string;
}

export interface Agent {
  id: string;
  name: string;
  emoji: string;
  role: string;
  model: string;
  status: "active" | "planned";
  color: string;
  tokens: number;
  cost: number;
  revenue: number;
  sessions: number;
  productions: AgentProduction[];
}

export interface DailyCost {
  date: string;
  totalTokens: number;
  totalCost: number;
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
}

export interface UsageTotals {
  totalTokens: number;
  totalCost: number;
}

export const FALLBACK_AGENTS: Agent[] = [
  {
    id: "dev", name: "C3-PO", emoji: "🤖", role: "Android App Builder",
    model: "anthropic/claude-opus-4-6", status: "active", color: "#6366f1",
    tokens: 2_847_320, cost: 42.18, revenue: 0, sessions: 14,
    productions: [
      { name: "Workout Timer", type: "Android APK", status: "verified", size: "22.3 MB", date: "2026-02-21" },
      { name: "GolfDeals", type: "Android APK", status: "verified", size: "51.4 MB", date: "2026-02-21" },
    ],
  },
  {
    id: "idea-engine", name: "Idea Engine", emoji: "💡", role: "Problem Discovery & Ranking",
    model: "anthropic/claude-sonnet-4-20250514", status: "active", color: "#eab308",
    tokens: 523_400, cost: 7.85, revenue: 0, sessions: 8, productions: [],
  },
  {
    id: "dropship-engine", name: "Dropship Engine", emoji: "🛍️", role: "Autonomous Store Builder",
    model: "anthropic/claude-sonnet-4-20250514", status: "active", color: "#22c55e",
    tokens: 891_200, cost: 13.37, revenue: 0, sessions: 5,
    productions: [
      { name: "Trending Store (Demo)", type: "React Storefront", status: "demo", size: "-", date: "2026-02-22" },
    ],
  },
  {
    id: "survival-kernel", name: "Survival Kernel", emoji: "🧠", role: "Meta-brain / Capital Allocator",
    model: "TBD", status: "planned", color: "#a855f7",
    tokens: 0, cost: 0, revenue: 0, sessions: 0, productions: [],
  },
  {
    id: "prediction-markets", name: "Prediction Markets", emoji: "🎲", role: "Polymarket Trader",
    model: "TBD", status: "planned", color: "#f97316",
    tokens: 0, cost: 0, revenue: 0, sessions: 0, productions: [],
  },
];

export const FALLBACK_DAILY_COSTS: DailyCost[] = Array.from({ length: 14 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (13 - i));
  const cost = Math.random() * 8 + 2;
  const tokens = Math.floor(cost * 50000 + Math.random() * 100000);
  return {
    date: d.toISOString().split("T")[0],
    totalTokens: tokens,
    totalCost: parseFloat(cost.toFixed(2)),
    input: Math.floor(tokens * 0.4),
    output: Math.floor(tokens * 0.3),
    cacheRead: Math.floor(tokens * 0.2),
    cacheWrite: Math.floor(tokens * 0.1),
  };
});

export const FALLBACK_TOTALS: UsageTotals = {
  totalTokens: FALLBACK_AGENTS.reduce((s, a) => s + a.tokens, 0),
  totalCost: parseFloat(FALLBACK_AGENTS.reduce((s, a) => s + a.cost, 0).toFixed(2)),
};
